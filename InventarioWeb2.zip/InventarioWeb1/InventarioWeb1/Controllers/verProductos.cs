﻿using InventarioWeb1.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InventarioWeb1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class verProductos : ControllerBase
    {
        [HttpGet]
        // Cuando solo vamos a recibir info usamos JsonResult
        public JsonResult VerProductos([FromBody] List <Producto> productos) { 

            return new JsonResult (productos);
        }
    }
}
