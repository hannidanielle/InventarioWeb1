﻿using Microsoft.AspNetCore.Http;
using InventarioWeb1.DTO;
using Microsoft.AspNetCore.Mvc;

namespace InventarioWeb1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class login : ControllerBase
    {
        [HttpPost]
        public bool Login([FromBody]Usuario usr)
        {
            bool regreso = false;
            if (usr != null)
            {
                if (usr.NombreUsuario == "esme" && usr.Contrasena == "123")
                    regreso = true;
            }
            return regreso;
        
        }
    }
}
