﻿namespace InventarioWeb1.DTO
{
    public class Inventario
    {
        public int NumeroInventario { get; set; }
        public Producto NombreProducto { get; set; }
        public int Cantidad { get; set; }
        public string Due { get; set; }
    }
}