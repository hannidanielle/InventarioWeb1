﻿namespace InventarioWeb1.DTO
{
    public class Producto
    {
        public int NumeroSKU { get; set; }
        public string NombreProducto { get; set; }
        public string DescripcionProducto { get; set; }
        public string FotoProducto { get; set; }
    }
}
