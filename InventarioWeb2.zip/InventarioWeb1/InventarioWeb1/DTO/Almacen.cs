﻿namespace InventarioWeb1.DTO
{
    public class Almacen
    {
        public int NumeroAlmacen { get; set; }
        public string NombreAlmacen { get; set; }
        public List <Inventario> Inventarios { get; set; }
    }
}
