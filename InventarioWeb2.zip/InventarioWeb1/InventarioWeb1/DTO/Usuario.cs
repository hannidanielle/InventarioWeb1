﻿namespace InventarioWeb1.DTO
{
    public class Usuario
    {
        public string Nombre { get; set; } 
        public string Contrasena { get; set;}
        public string NombreUsuario { get; set;}
        public string NivelAcceso { get; set; }
    }
}
